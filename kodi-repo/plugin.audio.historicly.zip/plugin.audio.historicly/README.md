<a href="https://kodi.tv">KODI<a> audio addon for the <a href="https://historicly.substack.com/podcast">Historic.ly</a> podcast.<br>

<img src="https://api.substack.com/feed/podcast/8079.jpg?v=09176bc266e10af7fa11a9cd5f94b932"><br>

You are listening to Historic.ly: a show where we decolonize history and debunk myths taught in school<br>

<a href="https://www.kodi.tv">Kodi</a> (formerly known as XBMC) is an award-winning free and open source (GPL) software media player and entertainment hub that can be installed on Linux, OSX, Windows, iOS and Android, featuring a 10-foot user interface for use with televisions and remote controls. It allows users to play and view most videos, music, podcasts, and other digital media files from local and network storage media and the internet.<br>

<b>^^^^ To install this addon ^^^^</b>, either use the <a href="https://www.tvaddons.co/github-browser-kodi/">Kodi Github installer</a> addon or save the .zip file downloaded from the 'clone or download' button (on this page above) to somewhere the Kodi can access (e.g. network drive or USB stick). Then on the Kodi, go to addons > install from zip file.<br>

<br><a href="https://www.kodi.tv"><img src="https://github.com/leopheard/Audio-Podcasts/blob/master/resources/media/about--devices.jpg?raw=true">
